-- Execute este script em um servidor PostgreSQL local caso nao use Docker.
-- No pgAdmin: abra Query Tool conectado ao banco postgres e rode este arquivo.

CREATE DATABASE clinica_medica;

-- Depois de criar o banco, rode a aplicacao Spring Boot.
-- O Flyway criara automaticamente as tabelas usando:
-- src/main/resources/db/migration/V1__create_schema.sql
