# Banco de dados PostgreSQL

O projeto usa PostgreSQL e Flyway. O banco precisa existir antes de iniciar a aplicação; as tabelas são criadas automaticamente pelo Flyway.

## ⚠️ Erro mais comum ao iniciar

```
FATAL: banco de dados "clinica_medica" não existe
```

Isso acontece porque o PostgreSQL **não cria o banco automaticamente**. Siga uma das opções abaixo.

---

## Opção 1: Docker (recomendado)

Na raiz do projeto:

```bash
docker compose up -d
```

Aguarde alguns segundos e rode:

```bash
mvn spring-boot:run
```

Dados usados:

- Banco: `clinica_medica`
- Usuário: `postgres`
- Senha: `postgres`
- Porta: `5432`

---

## Opção 2: PostgreSQL local ou pgAdmin

1. Abra o pgAdmin ou outro cliente PostgreSQL.
2. Conecte no servidor local.
3. Execute `database/create_database.sql` (ou rode o SQL abaixo):

```sql
CREATE DATABASE clinica_medica;
```

4. Rode a aplicação:

```bash
mvn spring-boot:run
```

---

## Config padrão no `application.yml`

```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/clinica_medica
    username: postgres
    password: postgres
```

Sobrescreva com variáveis de ambiente se necessário:

```bash
export DB_URL=jdbc:postgresql://localhost:5432/clinica_medica
export DB_USER=postgres
export DB_PASSWORD=postgres
```

---

## Migrations

O Flyway executa automaticamente ao iniciar a aplicação:

- `src/main/resources/db/migration/V1__create_schema.sql`

Cria as tabelas: `specialties`, `doctors`, `patients`, `users`, `appointments`, `waiting_list`.

---

## Dados iniciais

O `DataSeeder` cria ao iniciar:

- ADMIN: `admin@clinica.com` / `admin123`
- USER: `user@clinica.com` / `user123`
- Especialidades: Cardiologia e Pediatria
