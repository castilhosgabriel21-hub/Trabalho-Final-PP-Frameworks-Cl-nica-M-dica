# Clinica Medica - Trabalho Final

Sistema REST em Java 17 com Spring Boot 3, PostgreSQL, Spring Security com JWT, JPA, Flyway, validações e padrões GoF.

## Tecnologias

- Java 17
- Spring Boot 3.3.5
- Spring Web, Data JPA, Security, Validation
- PostgreSQL
- Flyway migrations
- Lombok
- JWT com java-jwt
- OpenPDF para relatorios PDF


## Banco de dados

O projeto ja vem com `docker-compose.yml` para PostgreSQL e scripts em `database/`.

Com Docker:

```bash
docker compose up -d
mvn spring-boot:run
```

Sem Docker, crie o banco manualmente executando `database/create_database.sql` no pgAdmin/PostgreSQL. As tabelas sao criadas automaticamente pelo Flyway.
## Como rodar

1. Crie o banco PostgreSQL:

```sql
create database clinica_medica;
```

2. Configure variaveis se necessario:

```bash
DB_URL=jdbc:postgresql://localhost:5432/clinica_medica
DB_USER=postgres
DB_PASSWORD=postgres
JWT_SECRET=clinica-medica-secret-dev
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=seu-email@gmail.com
MAIL_PASSWORD=sua-senha-de-app
MAIL_FROM=seu-email@gmail.com
```

3. Rode a aplicacao:

```bash
mvn spring-boot:run
```

A API sobe em `http://localhost:8080`.

Usuarios iniciais criados pelo `DataSeeder`:

- ADMIN: `admin@clinica.com` / `admin123`
- USER: `user@clinica.com` / `user123`


## Telas HTML

O projeto tambem possui telas Thymeleaf em `src/main/resources/templates/web`.

Acesse no navegador:

```text
http://localhost:8080/web/login
```

Telas disponiveis:

- `/web` dashboard
- `/web/patients` pacientes
- `/web/doctors` medicos
- `/web/specialties` especialidades
- `/web/appointments` consultas
- `/web/waiting-list` fila de espera
- `/web/users` usuarios
- `/web/reports` relatorios

As telas usam JWT no navegador e consomem os endpoints REST existentes.
## Autenticacao

```http
POST /auth/login
Content-Type: application/json

{
  "email": "admin@clinica.com",
  "password": "admin123"
}
```

Use o token retornado no header:

```http
Authorization: Bearer <token>
```

## Endpoints principais

- `POST /patients`
- `GET /patients?page=0&size=10&sort=name,asc`
- `GET /patients/{id}`
- `PUT /patients/{id}`
- `DELETE /patients/{id}`
- `POST /doctors` ADMIN
- `GET /doctors?name=ana&page=0&size=10&sort=name,asc`
- `GET /doctors/external`
- `POST /specialties`
- `GET /specialties`
- `POST /appointments` USER/ADMIN
- `GET /appointments?page=0&size=10&sort=dateTime,asc`
- `PUT /appointments/{id}`
- `POST /appointments/{id}/reminder` envia lembrete por email ao paciente
- `DELETE /appointments/{id}` ADMIN, cancela consulta e notifica fila
- `POST /waiting-list`
- `GET /waiting-list`
- `DELETE /waiting-list/{id}`
- `PUT /users/{id}` ADMIN
- `GET /reports/appointments/monthly?type=pdf&month=2026-06` ADMIN
- `GET /reports/appointments/monthly?type=csv&month=2026-06` ADMIN

## Exemplo de agendamento

```json
{
  "patientId": 1,
  "doctorId": 1,
  "dateTime": "2026-07-10T09:00:00",
  "notes": "Primeira consulta"
}
```

## Regras de negocio

- Consulta nao pode ser agendada no passado.
- Um medico nao pode ter duas consultas ativas no mesmo horario.
- Um paciente nao pode ter duas consultas ativas no mesmo horario.
- Conflitos lancam `ConsultaConflitoException`.
- Cancelamento atualiza o status para `CANCELLED` e aciona observadores da fila de espera.

## Envio de email

O envio de email usa SMTP via `spring-boot-starter-mail`. Configure as variaveis de ambiente antes de iniciar a aplicacao:

```bash
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=seu-email@gmail.com
MAIL_PASSWORD=sua-senha-de-app
MAIL_FROM=seu-email@gmail.com
MAIL_SMTP_AUTH=true
MAIL_SMTP_STARTTLS_ENABLE=true
```

Para Gmail, use uma senha de app da conta Google. A senha normal da conta geralmente nao funciona com SMTP.

## Padrões GoF usados

- Strategy: `NotificationStrategy` com email, SMS e WhatsApp.
- Observer: `AppointmentCancellationSubject`, `Observer` e `WaitingListNotifier` para cancelamentos.
- Factory: `ReportFactory` cria `PDFReport` ou `ExcelReport`.
- Facade: `AppointmentFacade` coordena validação, persistência e notificação do agendamento.
- Adapter: `MedicalCrmAdapter` adapta uma API ficticia de CRM medico para `ExternalDoctorGateway`.

## DER simples

```mermaid
erDiagram
    SPECIALTIES ||--o{ DOCTORS : possui
    PATIENTS ||--o{ APPOINTMENTS : agenda
    DOCTORS ||--o{ APPOINTMENTS : atende
    PATIENTS ||--o{ WAITING_LIST : entra
    SPECIALTIES ||--o{ WAITING_LIST : solicita
    USERS {
        bigint id PK
        string name
        string email
        string password
        string role
    }
    SPECIALTIES {
        bigint id PK
        string name
        string description
    }
    DOCTORS {
        bigint id PK
        string name
        string crm
        string email
        string phone
        bigint specialty_id FK
    }
    PATIENTS {
        bigint id PK
        string name
        string cpf
        string email
        string phone
    }
    APPOINTMENTS {
        bigint id PK
        datetime date_time
        string status
        bigint patient_id FK
        bigint doctor_id FK
    }
```

## Arquitetura

```mermaid
flowchart TB
    Client[Cliente REST] --> Controller[controller]
    Controller --> Facade[facade]
    Controller --> Service[service]
    Facade --> Service
    Service --> Repository[repository]
    Repository --> Entity[entity/JPA]
    Service --> Strategy[strategy]
    Service --> Observer[observer/event]
    Service --> Factory[factory]
    Service --> Adapter[adapter]
    Security[security/JWT] --> Controller
    Exception[exception/ControllerAdvice] --> Client
```

## Estrutura

```text
src/main/java/com/clinica
├── adapter
├── config
├── controller
├── dto
├── entity
├── event
├── exception
├── facade
├── factory
├── observer
├── repository
├── security
├── service
├── strategy
├── util
└── validation
```

## Observacoes para apresentacao

O projeto evita expor entidades nos controllers, usa DTOs de entrada/saida, centraliza excecoes com `@RestControllerAdvice`, aplica autenticação stateless por JWT e separa responsabilidades por camada. O banco e versionado por Flyway em `src/main/resources/db/migration`.



