const Clinica = (() => {
    const tokenKey = "clinicaMedicaToken";

    function token() {
        return localStorage.getItem(tokenKey);
    }

    function setToken(value) {
        localStorage.setItem(tokenKey, value);
    }

    function clearToken() {
        localStorage.removeItem(tokenKey);
    }

    function decodePayload(value) {
        if (!value) return null;

        try {
            const parts = value.split(".");
            if (parts.length < 2) return null;

            const base64 = parts[1].replaceAll("-", "+").replaceAll("_", "/");
            const padded = base64.padEnd(base64.length + ((4 - base64.length % 4) % 4), "=");
            return JSON.parse(atob(padded));
        } catch (error) {
            return null;
        }
    }

    function activePayload() {
        const payload = decodePayload(token());
        if (!payload) return null;

        if (payload.exp && Date.now() >= payload.exp * 1000) {
            clearToken();
            return null;
        }

        return payload;
    }

    function hasValidToken() {
        return activePayload() !== null;
    }

    function logout() {
        clearToken();
        window.location.href = "/web/login";
    }

    function redirectIfAnonymous() {
        if (!hasValidToken()) {
            window.location.href = "/web/login";
        }
    }

    function redirectIfAuthenticated() {
        if (hasValidToken()) {
            window.location.href = "/web";
        }
    }

    function userInfo() {
        const payload = activePayload();
        return payload ? { email: payload.sub, role: payload.role } : null;
    }

    function setUserBadge() {
        const target = document.querySelector("[data-user-badge]");
        if (!target) return;
        const user = userInfo();
        target.textContent = user ? `${user.email} (${user.role})` : "Visitante";
    }

    function activateNav() {
        const current = window.location.pathname;
        document.querySelectorAll(".nav a").forEach(link => {
            if (link.getAttribute("href") === current) link.classList.add("active");
        });
    }

    async function api(path, options = {}) {
        const headers = { ...(options.headers || {}) };

        if (options.body && !(options.body instanceof FormData)) {
            headers["Content-Type"] = "application/json";
        }

        if (token()) {
            headers.Authorization = `Bearer ${token()}`;
        }

        const response = await fetch(path, { ...options, headers });

        // Tratamento de erros de autenticação
        if (response.status === 401) {
            clearToken();
            if (!window.location.pathname.startsWith("/web/login")) {
                window.location.href = "/web/login";
            }
            throw new Error("Login necessário");
        }

        if (response.status === 403) {
            throw new Error(
                userInfo()?.role === "ADMIN"
                    ? "Acesso negado. Atualize a pagina e entre novamente como administrador."
                    : "Acesso negado para este perfil"
            );
        }

        // Tratamento de outros erros
        if (!response.ok) {
            const text = await response.text();

            try {
                const json = JSON.parse(text);

                // Melhor tratamento de erros - suporta múltiplos formatos
                const messages = json.messages || json.message || json.error || text;
                const errorMsg = Array.isArray(messages)
                    ? messages.join("; ")
                    : messages;

                throw new Error(errorMsg);
            } catch (error) {
                // Se já é um erro nosso, propaga
                if (error.message && error.message !== "Unexpected end of JSON input") {
                    throw error;
                }
                // Se não conseguiu parsear o JSON, mostra o texto bruto
                throw new Error(`Erro ${response.status}: ${text || "Erro na requisição"}`);
            }
        }

        // Respostas sem conteúdo
        if (response.status === 204) return null;

        // Determina o tipo de retorno
        const contentType = response.headers.get("content-type") || "";
        return contentType.includes("application/json") ? response.json() : response.blob();
    }

    async function login(email, password) {
        const data = await api("/auth/login", {
            method: "POST",
            body: JSON.stringify({ email, password })
        });
        setToken(data.token);
        return data;
    }

    function pageContent(data) {
        return Array.isArray(data) ? data : (data.content || []);
    }

    function escape(value) {
        return String(value ?? "")
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }

    function tableBody(id, rows, columns, actions) {
        const tbody = document.getElementById(id);
        if (!tbody) return;

        if (!rows.length) {
            tbody.innerHTML = `<tr><td colspan="${columns.length + (actions ? 1 : 0)}">Nenhum registro encontrado.</td></tr>`;
            return;
        }

        tbody.innerHTML = rows.map(row => {
            const cells = columns.map(column => {
                return `<td>${column.render ? column.render(row) : escape(row[column.key])}</td>`;
            }).join("");

            const actionCell = actions
                ? `<td><div class="actions">${actions(row)}</div></td>`
                : "";

            return `<tr>${cells}${actionCell}</tr>`;
        }).join("");
    }

    function fillSelect(id, rows, getLabel) {
        const select = document.getElementById(id);
        if (!select) return;

        const first = select.dataset.placeholder || "Selecione";

        select.innerHTML =
            `<option value="">${escape(first)}</option>` +
            rows.map(row => `<option value="${row.id}">${escape(getLabel(row))}</option>`).join("");
    }

    function formValues(form) {
        const data = {};
        new FormData(form).forEach((value, key) => {
            if (value !== "") data[key] = value;
        });
        return data;
    }

    function resetForm(id) {
        const form = document.getElementById(id);
        if (!form) return;

        form.reset();

        const hiddenId = form.querySelector("input[name='id']");
        if (hiddenId) hiddenId.value = "";
    }

    function notice(message, type = "ok") {
        const box = document.getElementById("notice");
        if (!box) return;

        box.textContent = message;
        box.className = `notice show ${type}`;

        window.clearTimeout(box.dataset.timer);
        box.dataset.timer = window.setTimeout(() => {
            box.className = "notice";
        }, 4200);
    }

    function dateTimeForInput(value) {
        return value ? value.slice(0, 16) : "";
    }

    function badgeStatus(status) {
        const css = status === "Agendada" ? "success" :
                    status === "Concluída" ? "info" :
                    status === "Em espera" ? "warn" :
                    "danger"; // Cancelada ou outros

        return `<span class="badge ${css}">${escape(status)}</span>`;
    }

    function downloadBlob(blob, fileName) {
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
    }

    // Inicialização quando o DOM estiver pronto
    document.addEventListener("DOMContentLoaded", () => {
        activateNav();
        setUserBadge();

        document.querySelectorAll("[data-logout]").forEach(button => {
            button.addEventListener("click", logout);
        });
    });

    // API pública do módulo
    return {
        api,
        login,
        logout,
        redirectIfAnonymous,
        redirectIfAuthenticated,
        userInfo,
        pageContent,
        tableBody,
        fillSelect,
        formValues,
        resetForm,
        notice,
        escape,
        dateTimeForInput,
        badgeStatus,
        downloadBlob
    };
})();
