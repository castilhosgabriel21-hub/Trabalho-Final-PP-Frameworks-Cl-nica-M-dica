create table specialties (
    id bigserial primary key,
    name varchar(255) not null unique,
    description varchar(500),
    created_at timestamp not null,
    updated_at timestamp not null
);
create table doctors (
    id bigserial primary key,
    name varchar(255) not null,
    crm varchar(255) not null unique,
    email varchar(255) not null unique,
    phone varchar(255) not null,
    specialty_id bigint not null references specialties(id),
    created_at timestamp not null,
    updated_at timestamp not null
);
create table patients (
    id bigserial primary key,
    name varchar(255) not null,
    cpf varchar(14) not null unique,
    email varchar(255) not null unique,
    phone varchar(255) not null,
    created_at timestamp not null,
    updated_at timestamp not null
);
create table users (
    id bigserial primary key,
    name varchar(255) not null,
    email varchar(255) not null unique,
    password varchar(255) not null,
    role varchar(20) not null check (role in ('ADMIN','USER')),
    created_at timestamp not null,
    updated_at timestamp not null
);
create table appointments (
    id bigserial primary key,
    date_time timestamp not null,
    status varchar(20) not null check (status in ('SCHEDULED','CANCELLED','COMPLETED','WAITING')),
    notes varchar(500),
    patient_id bigint not null references patients(id),
    doctor_id bigint not null references doctors(id),
    created_at timestamp not null,
    updated_at timestamp not null
);
create index idx_appointments_date_time on appointments(date_time);
create index idx_appointments_status on appointments(status);
create unique index uk_doctor_time_active on appointments(doctor_id, date_time) where status <> 'CANCELLED';
create unique index uk_patient_time_active on appointments(patient_id, date_time) where status <> 'CANCELLED';
create table waiting_list (
    id bigserial primary key,
    patient_id bigint not null references patients(id),
    specialty_id bigint not null references specialties(id),
    desired_date_time timestamp,
    notified boolean not null default false,
    created_at timestamp not null,
    updated_at timestamp not null
);

