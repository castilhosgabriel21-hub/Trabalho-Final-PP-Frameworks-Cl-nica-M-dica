alter table appointments
    alter column created_at set default current_timestamp,
    alter column updated_at set default current_timestamp;

