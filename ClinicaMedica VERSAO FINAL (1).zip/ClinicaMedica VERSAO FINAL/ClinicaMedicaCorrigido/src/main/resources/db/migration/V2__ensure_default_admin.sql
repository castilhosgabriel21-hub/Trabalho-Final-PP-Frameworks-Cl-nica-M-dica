update users
set role = 'ADMIN',
    updated_at = current_timestamp
where email = 'admin@clinica.com'
  and role <> 'ADMIN';
