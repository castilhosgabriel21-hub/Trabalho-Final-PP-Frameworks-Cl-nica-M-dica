package com.clinica.factory;

import com.clinica.entity.Appointment;
import java.nio.charset.StandardCharsets; import java.util.List;

public class ExcelReport implements Report {
    public byte[] generate(List<Appointment> appointments) {
        var csv = new StringBuilder("data,paciente,medico,status\n");
        appointments.forEach(a -> csv.append(a.getDateTime()).append(',').append(a.getPatient().getName()).append(',').append(a.getDoctor().getName()).append(',').append(a.getStatus()).append('\n'));
        return csv.toString().getBytes(StandardCharsets.UTF_8);
    }
    public String contentType() { return "text/csv"; }
    public String fileName() { return "relatorio-consultas.csv"; }
}

