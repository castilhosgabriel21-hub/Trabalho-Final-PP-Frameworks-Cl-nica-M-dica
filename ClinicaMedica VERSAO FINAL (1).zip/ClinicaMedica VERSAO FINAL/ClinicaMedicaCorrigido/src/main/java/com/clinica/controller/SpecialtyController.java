package com.clinica.controller;
import com.clinica.dto.*; import com.clinica.service.SpecialtyService; import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.data.domain.*; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/specialties") @RequiredArgsConstructor
public class SpecialtyController {
    private final SpecialtyService service;
    @PostMapping @ResponseStatus(HttpStatus.CREATED) public SpecialtyResponse create(@RequestBody @Valid SpecialtyRequest r) { return service.create(r); }
    @GetMapping public Page<SpecialtyResponse> list(Pageable pageable) { return service.list(pageable); }
    @GetMapping("/{id}") public SpecialtyResponse find(@PathVariable Long id) { return service.find(id); }
    @PutMapping("/{id}") public SpecialtyResponse update(@PathVariable Long id, @RequestBody @Valid SpecialtyRequest r) { return service.update(id, r); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id) { service.delete(id); }
}

