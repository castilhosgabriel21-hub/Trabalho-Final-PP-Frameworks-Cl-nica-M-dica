package com.clinica.adapter;
public record ExternalDoctorResponse(String name, String crm, String specialty) {}

