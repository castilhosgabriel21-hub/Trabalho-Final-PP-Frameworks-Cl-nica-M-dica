package com.clinica.entity;

public enum Role { ADMIN, USER }

