package com.clinica.validation;

import jakarta.validation.Constraint; import jakarta.validation.Payload;
import java.lang.annotation.*;

@Documented @Constraint(validatedBy = FutureAppointmentValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER}) @Retention(RetentionPolicy.RUNTIME)
public @interface FutureAppointment {
    String message() default "a consulta deve ser futura";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}

