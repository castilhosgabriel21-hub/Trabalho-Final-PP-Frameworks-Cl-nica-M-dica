package com.clinica.config;

import com.clinica.entity.*; import com.clinica.repository.*; import lombok.RequiredArgsConstructor; import org.springframework.boot.CommandLineRunner; import org.springframework.context.annotation.Bean; import org.springframework.context.annotation.Configuration; import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration @RequiredArgsConstructor
public class DataSeeder {
    private final PasswordEncoder passwordEncoder;
    @Bean CommandLineRunner seed(UserRepository users, SpecialtyRepository specialties) { return args -> {
        ensureDefaultAdmin(users);
        if (!users.existsByEmail("user@clinica.com")) users.save(User.builder().name("Usuario").email("user@clinica.com").password(passwordEncoder.encode("user123")).role(Role.USER).build());
        if (!specialties.existsByName("Cardiologia")) specialties.save(Specialty.builder().name("Cardiologia").description("Atendimento cardiologico").build());
        if (!specialties.existsByName("Pediatria")) specialties.save(Specialty.builder().name("Pediatria").description("Atendimento infantil").build());
    }; }

    private void ensureDefaultAdmin(UserRepository users) {
        users.findByEmail("admin@clinica.com").ifPresentOrElse(admin -> {
            var changed = false;
            if (admin.getRole() != Role.ADMIN) {
                admin.setRole(Role.ADMIN);
                changed = true;
            }
            if (!passwordEncoder.matches("admin123", admin.getPassword())) {
                admin.setPassword(passwordEncoder.encode("admin123"));
                changed = true;
            }
            if (changed) users.save(admin);
        }, () -> users.save(User.builder().name("Administrador").email("admin@clinica.com").password(passwordEncoder.encode("admin123")).role(Role.ADMIN).build()));
    }
}

