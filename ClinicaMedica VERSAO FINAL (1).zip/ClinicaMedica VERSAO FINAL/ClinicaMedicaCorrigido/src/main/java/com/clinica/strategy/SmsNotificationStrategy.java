package com.clinica.strategy;
import lombok.extern.slf4j.Slf4j; import org.springframework.stereotype.Component;
@Slf4j @Component
public class SmsNotificationStrategy implements NotificationStrategy { public String channel() { return "SMS"; } public void send(String destination, String message) { log.info("SMS para {}: {}", destination, message); } }

