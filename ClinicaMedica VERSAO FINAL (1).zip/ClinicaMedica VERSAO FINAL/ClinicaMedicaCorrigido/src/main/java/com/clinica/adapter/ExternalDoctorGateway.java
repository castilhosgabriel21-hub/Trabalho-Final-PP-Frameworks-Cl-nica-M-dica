package com.clinica.adapter;
import java.util.List;
public interface ExternalDoctorGateway { List<ExternalDoctorResponse> fetchDoctors(); }

