package com.clinica.repository;
import com.clinica.entity.Appointment;
import com.clinica.entity.AppointmentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    boolean existsByDoctorIdAndDateTimeAndStatusNot(Long doctorId, LocalDateTime dateTime, AppointmentStatus status);
    boolean existsByPatientIdAndDateTimeAndStatusNot(Long patientId, LocalDateTime dateTime, AppointmentStatus status);
    boolean existsByDoctorIdAndDateTimeAndStatusNotAndIdNot(Long doctorId, LocalDateTime dateTime, AppointmentStatus status, Long id);
    boolean existsByPatientIdAndDateTimeAndStatusNotAndIdNot(Long patientId, LocalDateTime dateTime, AppointmentStatus status, Long id);
    @Override
    @EntityGraph(attributePaths = {"patient", "doctor", "doctor.specialty"})
    Page<Appointment> findAll(Pageable pageable);
    @Override
    @EntityGraph(attributePaths = {"patient", "doctor", "doctor.specialty"})
    Optional<Appointment> findById(Long id);
    @EntityGraph(attributePaths = {"patient", "doctor", "doctor.specialty"})
    Page<Appointment> findAllByOrderByDateTimeAsc(Pageable pageable);
    @EntityGraph(attributePaths = {"patient", "doctor", "doctor.specialty"})
    List<Appointment> findByDateTimeBetween(LocalDateTime start, LocalDateTime end);
}
