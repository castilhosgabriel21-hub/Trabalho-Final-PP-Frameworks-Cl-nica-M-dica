package com.clinica.factory;
import com.clinica.exception.BusinessException; import org.springframework.stereotype.Component;
@Component
public class ReportFactory { public Report create(String type) { return switch (type.toLowerCase()) { case "pdf" -> new PDFReport(); case "excel", "csv" -> new ExcelReport(); default -> throw new BusinessException("Tipo de relatorio invalido"); }; } }

