package com.clinica.dto;
import com.clinica.validation.FutureAppointment;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
public record AppointmentRequest(@NotNull Long patientId, @NotNull Long doctorId, @FutureAppointment LocalDateTime dateTime, String notes) {}

