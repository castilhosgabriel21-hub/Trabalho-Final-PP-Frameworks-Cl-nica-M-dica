package com.clinica.dto;
import jakarta.validation.constraints.Email; import jakarta.validation.constraints.NotBlank;
public record PatientRequest(@NotBlank String name, @NotBlank String cpf, @Email @NotBlank String email, @NotBlank String phone) {}

