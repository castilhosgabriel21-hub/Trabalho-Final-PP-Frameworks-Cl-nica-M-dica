package com.clinica.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name = "waiting_list")
public class WaitingListEntry extends BaseEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;
    @ManyToOne(optional = false) @JoinColumn(name = "specialty_id", nullable = false)
    private Specialty specialty;
    @Column(name = "desired_date_time")
    private LocalDateTime desiredDateTime;
    @Column(nullable = false)
    private boolean notified;
}

