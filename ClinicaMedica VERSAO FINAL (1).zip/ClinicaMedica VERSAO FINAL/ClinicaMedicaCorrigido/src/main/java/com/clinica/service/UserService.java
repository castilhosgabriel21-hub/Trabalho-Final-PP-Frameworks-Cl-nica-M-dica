package com.clinica.service;

import com.clinica.dto.*; import com.clinica.entity.Role; import com.clinica.entity.User; import com.clinica.exception.BusinessException; import com.clinica.exception.ResourceNotFoundException; import com.clinica.repository.UserRepository; import com.clinica.util.DtoMapper;
import lombok.RequiredArgsConstructor; import org.springframework.data.domain.Page; import org.springframework.data.domain.Pageable; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.stereotype.Service;

@Service @RequiredArgsConstructor
public class UserService {
    private final UserRepository repository; private final PasswordEncoder passwordEncoder;
    public UserResponse create(UserRequest request) { return DtoMapper.user(repository.save(User.builder().name(request.name()).email(request.email()).password(passwordEncoder.encode(request.password())).role(request.role()).build())); }
    public Page<UserResponse> list(Pageable pageable) { return repository.findAll(pageable).map(DtoMapper::user); }
    public User getEntity(Long id) { return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Usuario nao encontrado")); }
    public UserResponse find(Long id) { return DtoMapper.user(getEntity(id)); }
    public UserResponse update(Long id, UserRequest request) {
        var u = getEntity(id);
        ensureAdminWillRemain(u, request.role());
        u.setName(request.name());
        u.setEmail(request.email());
        u.setPassword(passwordEncoder.encode(request.password()));
        u.setRole(request.role());
        return DtoMapper.user(repository.save(u));
    }
    public void delete(Long id) {
        var u = getEntity(id);
        ensureAdminWillRemain(u, null);
        repository.delete(u);
    }

    private void ensureAdminWillRemain(User user, Role newRole) {
        var removingAdminRole = user.getRole() == Role.ADMIN && newRole != Role.ADMIN;
        if (removingAdminRole && repository.countByRole(Role.ADMIN) <= 1) {
            throw new BusinessException("Nao e possivel remover o ultimo administrador do sistema");
        }
    }
}
