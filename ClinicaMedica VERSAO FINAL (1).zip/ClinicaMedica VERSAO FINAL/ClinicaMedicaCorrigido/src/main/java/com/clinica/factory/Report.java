package com.clinica.factory;
import com.clinica.entity.Appointment; import java.util.List;
public interface Report { byte[] generate(List<Appointment> appointments); String contentType(); String fileName(); }

