package com.clinica.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "doctors")
public class Doctor extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String name;

    @NotBlank
    @Column(nullable = false, unique = true)
    private String crm;

    @Email
    @NotBlank
    @Column(nullable = false, unique = true)
    private String email;

    @NotBlank
    @Column(nullable = false)
    private String phone;

    @ManyToOne(optional = false)
    @JoinColumn(name = "specialty_id", nullable = false)
    private Specialty specialty;

    @OneToMany(mappedBy = "doctor")
    private List<Appointment> appointments = new ArrayList<>();

    // Construtores
    public Doctor() {
        this.appointments = new ArrayList<>();
    }

    public Doctor(Long id, String name, String crm, String email, String phone,
                  Specialty specialty, List<Appointment> appointments) {
        this.id = id;
        this.name = name;
        this.crm = crm;
        this.email = email;
        this.phone = phone;
        this.specialty = specialty;
        this.appointments = appointments != null ? appointments : new ArrayList<>();
    }

    // Builder manual
    public static DoctorBuilder builder() {
        return new DoctorBuilder();
    }

    public static class DoctorBuilder {
        private Long id;
        private String name;
        private String crm;
        private String email;
        private String phone;
        private Specialty specialty;
        private List<Appointment> appointments = new ArrayList<>();

        public DoctorBuilder id(Long id) { this.id = id; return this; }
        public DoctorBuilder name(String name) { this.name = name; return this; }
        public DoctorBuilder crm(String crm) { this.crm = crm; return this; }
        public DoctorBuilder email(String email) { this.email = email; return this; }
        public DoctorBuilder phone(String phone) { this.phone = phone; return this; }
        public DoctorBuilder specialty(Specialty specialty) { this.specialty = specialty; return this; }
        public DoctorBuilder appointments(List<Appointment> appointments) {
            this.appointments = appointments;
            return this;
        }

        public Doctor build() {
            return new Doctor(id, name, crm, email, phone, specialty, appointments);
        }
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCrm() { return crm; }
    public void setCrm(String crm) { this.crm = crm; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public Specialty getSpecialty() { return specialty; }
    public void setSpecialty(Specialty specialty) { this.specialty = specialty; }

    public List<Appointment> getAppointments() { return appointments; }
    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }
}