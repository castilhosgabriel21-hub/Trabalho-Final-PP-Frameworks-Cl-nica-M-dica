package com.clinica.controller;

import com.clinica.dto.WaitingListNotificationRequest;
import com.clinica.dto.WaitingListRequest;
import com.clinica.dto.WaitingListResponse;
import com.clinica.service.WaitingListService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/waiting-list")
@RequiredArgsConstructor
public class WaitingListController {
    private final WaitingListService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public WaitingListResponse create(@RequestBody @Valid WaitingListRequest request) {
        return service.create(request);
    }

    @GetMapping
    public Page<WaitingListResponse> list(Pageable pageable) {
        return service.list(pageable);
    }

    @GetMapping("/{id}")
    public WaitingListResponse find(@PathVariable Long id) {
        return service.find(id);
    }

    @PostMapping("/{id}/notify")
    public WaitingListResponse notifyByEmail(@PathVariable Long id, @RequestBody @Valid WaitingListNotificationRequest request) {
        return service.notifyByEmail(id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}