package com.clinica.strategy;
public interface NotificationStrategy { String channel(); void send(String destination, String message); }

