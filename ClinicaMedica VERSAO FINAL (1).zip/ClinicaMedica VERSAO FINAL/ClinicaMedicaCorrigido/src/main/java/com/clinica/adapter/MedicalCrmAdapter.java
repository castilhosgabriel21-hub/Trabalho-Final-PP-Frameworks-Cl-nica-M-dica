package com.clinica.adapter;
import org.springframework.stereotype.Component; import java.util.List;
@Component
public class MedicalCrmAdapter implements ExternalDoctorGateway {
    public List<ExternalDoctorResponse> fetchDoctors() { return List.of(new ExternalDoctorResponse("Dra. Ana Souza", "CRM-EXT-100", "Cardiologia"), new ExternalDoctorResponse("Dr. Bruno Lima", "CRM-EXT-200", "Pediatria")); }
}

