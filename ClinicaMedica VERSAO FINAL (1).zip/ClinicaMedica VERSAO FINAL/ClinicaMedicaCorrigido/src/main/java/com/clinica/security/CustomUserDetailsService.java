package com.clinica.security;
import com.clinica.repository.UserRepository; import lombok.RequiredArgsConstructor; import org.springframework.security.core.userdetails.*; import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {
    private final UserRepository repository;
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException { return repository.findByEmail(username).orElseThrow(() -> new UsernameNotFoundException("Usuario nao encontrado")); }
}

