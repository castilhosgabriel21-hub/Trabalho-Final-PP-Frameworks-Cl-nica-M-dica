package com.clinica.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "specialties")
public class Specialty extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false, unique = true)
    private String name;

    @Column(length = 500)
    private String description;

    @OneToMany(mappedBy = "specialty")
    private List<Doctor> doctors = new ArrayList<>();

    // Construtores
    public Specialty() {
        this.doctors = new ArrayList<>();
    }

    public Specialty(Long id, String name, String description, List<Doctor> doctors) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.doctors = doctors != null ? doctors : new ArrayList<>();
    }

    // Builder manual
    public static SpecialtyBuilder builder() {
        return new SpecialtyBuilder();
    }

    public static class SpecialtyBuilder {
        private Long id;
        private String name;
        private String description;
        private List<Doctor> doctors = new ArrayList<>();

        public SpecialtyBuilder id(Long id) {
            this.id = id;
            return this;
        }

        public SpecialtyBuilder name(String name) {
            this.name = name;
            return this;
        }

        public SpecialtyBuilder description(String description) {
            this.description = description;
            return this;
        }

        public SpecialtyBuilder doctors(List<Doctor> doctors) {
            this.doctors = doctors;
            return this;
        }

        public Specialty build() {
            return new Specialty(id, name, description, doctors);
        }
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Doctor> getDoctors() {
        return doctors;
    }

    public void setDoctors(List<Doctor> doctors) {
        this.doctors = doctors;
    }
}