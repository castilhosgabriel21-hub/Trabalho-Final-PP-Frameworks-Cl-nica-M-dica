package com.clinica.security;

import com.auth0.jwt.JWT; import com.auth0.jwt.algorithms.Algorithm; import com.auth0.jwt.exceptions.JWTVerificationException; import com.clinica.entity.User;
import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Service;
import java.time.Instant; import java.time.temporal.ChronoUnit;

@Service
public class TokenService {
    @Value("${api.security.token-secret}") private String secret;
    @Value("${api.security.issuer}") private String issuer;
    @Value("${api.security.expiration-hours}") private long expirationHours;
    public String generate(User user) { return JWT.create().withIssuer(issuer).withSubject(user.getEmail()).withClaim("role", user.getRole().name()).withExpiresAt(Instant.now().plus(expirationHours, ChronoUnit.HOURS)).sign(Algorithm.HMAC256(secret)); }
    public String validate(String token) { try { return JWT.require(Algorithm.HMAC256(secret)).withIssuer(issuer).build().verify(token).getSubject(); } catch (JWTVerificationException ex) { return null; } }
}

