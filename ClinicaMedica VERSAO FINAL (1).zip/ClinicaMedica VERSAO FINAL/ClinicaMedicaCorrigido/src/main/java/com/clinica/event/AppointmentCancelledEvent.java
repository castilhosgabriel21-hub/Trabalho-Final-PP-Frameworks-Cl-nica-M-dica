package com.clinica.event;
import com.clinica.entity.Appointment;
public record AppointmentCancelledEvent(Appointment appointment) {}

