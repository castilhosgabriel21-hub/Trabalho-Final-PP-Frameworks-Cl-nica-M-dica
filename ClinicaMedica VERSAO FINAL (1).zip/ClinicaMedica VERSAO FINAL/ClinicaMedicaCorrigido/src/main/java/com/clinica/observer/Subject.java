package com.clinica.observer;

import com.clinica.event.AppointmentCancelledEvent;

public interface Subject {
    void attach(Observer observer);
    void detach(Observer observer);
    void notifyObservers(AppointmentCancelledEvent event);
}