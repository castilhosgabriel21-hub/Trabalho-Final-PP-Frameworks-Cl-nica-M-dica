package com.clinica.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {
    @GetMapping("/")
    public String root() {
        return "redirect:/web";
    }

    @GetMapping("/web")
    public String dashboard() {
        return "web/index";
    }

    @GetMapping("/web/login")
    public String login() {
        return "web/login";
    }

    @GetMapping("/web/patients")
    public String patients() {
        return "web/patients";
    }

    @GetMapping("/web/doctors")
    public String doctors() {
        return "web/doctors";
    }

    @GetMapping("/web/specialties")
    public String specialties() {
        return "web/specialties";
    }

    @GetMapping("/web/appointments")
    public String appointments() {
        return "web/appointments";
    }

    @GetMapping("/web/waiting-list")
    public String waitingList() {
        return "web/waiting-list";
    }

    @GetMapping("/web/users")
    public String users() {
        return "web/users";
    }

    @GetMapping("/web/reports")
    public String reports() {
        return "web/reports";
    }
}