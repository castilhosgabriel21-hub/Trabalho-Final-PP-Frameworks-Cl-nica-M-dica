package com.clinica.util;

import com.clinica.dto.*; import com.clinica.entity.*;

public final class DtoMapper {
    private DtoMapper() {}
    public static PatientResponse patient(Patient p) { return new PatientResponse(p.getId(), p.getName(), p.getCpf(), p.getEmail(), p.getPhone()); }
    public static SpecialtyResponse specialty(Specialty s) { return new SpecialtyResponse(s.getId(), s.getName(), s.getDescription()); }
    public static DoctorResponse doctor(Doctor d) { return new DoctorResponse(d.getId(), d.getName(), d.getCrm(), d.getEmail(), d.getPhone(), specialty(d.getSpecialty())); }
    public static AppointmentResponse appointment(Appointment a) { return new AppointmentResponse(a.getId(), a.getDateTime(), a.getStatus(), a.getNotes(), patient(a.getPatient()), doctor(a.getDoctor())); }
    public static UserResponse user(User u) { return new UserResponse(u.getId(), u.getName(), u.getEmail(), u.getRole()); }
}

