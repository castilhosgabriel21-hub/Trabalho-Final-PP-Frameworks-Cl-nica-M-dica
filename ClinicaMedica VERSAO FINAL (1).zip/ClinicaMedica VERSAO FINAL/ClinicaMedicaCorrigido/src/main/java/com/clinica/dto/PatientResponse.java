package com.clinica.dto;
public record PatientResponse(Long id, String name, String cpf, String email, String phone) {}

