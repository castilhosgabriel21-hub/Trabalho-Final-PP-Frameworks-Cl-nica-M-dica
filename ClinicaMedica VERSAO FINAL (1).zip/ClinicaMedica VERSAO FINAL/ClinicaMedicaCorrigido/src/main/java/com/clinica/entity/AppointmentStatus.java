package com.clinica.entity;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum AppointmentStatus {
    SCHEDULED("Agendada"),
    COMPLETED("Concluída"),
    CANCELLED("Cancelada"),
    WAITING("Em espera");

    private final String label;

    AppointmentStatus(String label) {
        this.label = label;
    }

    @JsonValue
    public String getLabel() {
        return label;
    }

    @JsonCreator
    public static AppointmentStatus fromValue(String value) {
        if (value == null) return null;
        for (AppointmentStatus status : values()) {
            if (status.name().equalsIgnoreCase(value) || status.label.equalsIgnoreCase(value)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Status de consulta inválido: " + value);
    }
}
