package com.clinica.service;

import com.clinica.dto.*;
import com.clinica.entity.*;
import com.clinica.event.AppointmentCancelledEvent;
import com.clinica.exception.BusinessException;
import com.clinica.exception.ResourceNotFoundException;
import com.clinica.observer.AppointmentCancellationSubject;
import com.clinica.repository.*;
import com.clinica.util.DtoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;

@Service
public class AppointmentService {

    private static final Logger log = LoggerFactory.getLogger(AppointmentService.class);

    private final AppointmentRepository repository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final WaitingListRepository waitingListRepository;
    private final AppointmentCancellationSubject cancellationSubject;
    private final NotificationService notificationService;

    public AppointmentService(
            AppointmentRepository repository,
            PatientRepository patientRepository,
            DoctorRepository doctorRepository,
            WaitingListRepository waitingListRepository,
            AppointmentCancellationSubject cancellationSubject,
            NotificationService notificationService) {
        this.repository = repository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
        this.waitingListRepository = waitingListRepository;
        this.cancellationSubject = cancellationSubject;
        this.notificationService = notificationService;
    }

    @Transactional
    public AppointmentResponse createEntity(AppointmentRequest request) {
        var patient = patientRepository.findById(request.patientId())
                .orElseThrow(() -> new ResourceNotFoundException("Paciente não encontrado"));
        var doctor = doctorRepository.findById(request.doctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Médico não encontrado"));

        if (repository.existsByDoctorIdAndDateTimeAndStatusNot(
                doctor.getId(), request.dateTime(), AppointmentStatus.CANCELLED)) {
            throw new BusinessException("Médico já possui consulta neste horário");
        }

        if (repository.existsByPatientIdAndDateTimeAndStatusNot(
                patient.getId(), request.dateTime(), AppointmentStatus.CANCELLED)) {
            throw new BusinessException("Paciente já possui consulta neste horário");
        }

        var appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setDoctor(doctor);
        appointment.setDateTime(request.dateTime());
        appointment.setNotes(request.notes());
        appointment.setStatus(AppointmentStatus.SCHEDULED);

        var saved = repository.save(appointment);
        log.info("Agendamento criado: ID={}, Paciente={}, Médico={}",
                saved.getId(), patient.getName(), doctor.getName());

        notificationService.send("EMAIL", patient.getEmail(),
                "Consulta agendada para " + request.dateTime());

        return DtoMapper.appointment(saved);
    }

    @Transactional(readOnly = true)
    public Page<AppointmentResponse> list(Pageable pageable) {
        return repository.findAll(pageable).map(DtoMapper::appointment);
    }

    @Transactional(readOnly = true)
    public AppointmentResponse find(Long id) {
        return DtoMapper.appointment(getEntity(id));
    }

    @Transactional
    public AppointmentResponse update(Long id, AppointmentRequest request) {
        var appointment = getEntity(id);

        if (appointment.getStatus() == AppointmentStatus.CANCELLED) {
            throw new BusinessException("Não é possível editar agendamento cancelado");
        }

        var patient = patientRepository.findById(request.patientId())
                .orElseThrow(() -> new ResourceNotFoundException("Paciente não encontrado"));
        var doctor = doctorRepository.findById(request.doctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Médico não encontrado"));

        if (repository.existsByDoctorIdAndDateTimeAndStatusNotAndIdNot(
                doctor.getId(), request.dateTime(), AppointmentStatus.CANCELLED, id)) {
            throw new BusinessException("Médico já possui consulta neste horário");
        }

        if (repository.existsByPatientIdAndDateTimeAndStatusNotAndIdNot(
                patient.getId(), request.dateTime(), AppointmentStatus.CANCELLED, id)) {
            throw new BusinessException("Paciente já possui consulta neste horário");
        }

        appointment.setPatient(patient);
        appointment.setDoctor(doctor);
        appointment.setDateTime(request.dateTime());
        appointment.setNotes(request.notes());

        return DtoMapper.appointment(repository.save(appointment));
    }

    @Transactional
    public AppointmentResponse updateStatus(Long id, String statusStr) {
        var appointment = getEntity(id);

        if (appointment.getStatus() == AppointmentStatus.CANCELLED) {
            throw new BusinessException("Não é possível mudar status de consulta cancelada");
        }

        AppointmentStatus newStatus;
        try {
            newStatus = AppointmentStatus.fromValue(statusStr);
        } catch (IllegalArgumentException e) {
            throw new BusinessException("Status inválido: " + statusStr);
        }

        if (newStatus == AppointmentStatus.COMPLETED &&
                appointment.getDateTime().isAfter(LocalDateTime.now())) {
            throw new BusinessException(
                    "Não é possível marcar como concluída uma consulta que ainda não aconteceu");
        }

        appointment.setStatus(newStatus);
        return DtoMapper.appointment(repository.save(appointment));
    }

    @Transactional
    public void cancel(Long id) {
        var appointment = getEntity(id);

        if (appointment.getStatus() == AppointmentStatus.CANCELLED) {
            throw new BusinessException("Agendamento já foi cancelado");
        }

        appointment.setStatus(AppointmentStatus.CANCELLED);
        repository.save(appointment);

        log.info("Agendamento cancelado: ID={}, Paciente={}",
                appointment.getId(), appointment.getPatient().getName());

        cancellationSubject.notifyObservers(new AppointmentCancelledEvent(appointment));
    }

    public void sendReminder(Long id) {
        var appointment = getEntity(id);
        var message = String.format(
                "Lembrete: Você tem uma consulta com %s em %s",
                appointment.getDoctor().getName(),
                appointment.getDateTime()
        );
        notificationService.send("EMAIL", appointment.getPatient().getEmail(), message);
    }

    @Transactional(readOnly = true)
    public List<Appointment> monthlyAppointments(YearMonth yearMonth) {
        LocalDateTime start = yearMonth.atDay(1).atStartOfDay();
        LocalDateTime end = yearMonth.atEndOfMonth().atTime(23, 59, 59);
        return repository.findByDateTimeBetween(start, end);
    }

    private Appointment getEntity(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Agendamento não encontrado"));
    }
}
