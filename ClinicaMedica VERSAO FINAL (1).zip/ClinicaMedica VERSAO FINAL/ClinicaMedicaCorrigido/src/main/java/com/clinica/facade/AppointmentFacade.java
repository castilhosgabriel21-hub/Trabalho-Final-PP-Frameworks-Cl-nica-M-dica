package com.clinica.facade;

import com.clinica.dto.AppointmentRequest;
import com.clinica.dto.AppointmentResponse;
import com.clinica.service.AppointmentService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class AppointmentFacade {

    private final AppointmentService appointmentService;

    public AppointmentFacade(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    @Transactional
    public AppointmentResponse schedule(AppointmentRequest request) {
        return appointmentService.createEntity(request);
    }
}