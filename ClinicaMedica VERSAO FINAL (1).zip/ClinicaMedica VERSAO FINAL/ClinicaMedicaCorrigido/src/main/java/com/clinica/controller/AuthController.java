package com.clinica.controller;

import com.clinica.dto.*; import com.clinica.entity.User; import com.clinica.security.TokenService; import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.security.authentication.*; import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/auth") @RequiredArgsConstructor
public class AuthController {
    private final AuthenticationManager authenticationManager; private final TokenService tokenService;
    @PostMapping("/login") public TokenResponse login(@RequestBody @Valid LoginRequest request) {
        var auth = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.email(), request.password()));
        return new TokenResponse(tokenService.generate((User) auth.getPrincipal()), "Bearer");
    }
}

