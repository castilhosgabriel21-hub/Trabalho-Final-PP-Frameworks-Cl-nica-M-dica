package com.clinica.observer;

import com.clinica.event.AppointmentCancelledEvent;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Component
public class AppointmentCancellationSubject implements Subject {

    private final List<Observer> observers = new CopyOnWriteArrayList<>();

    public AppointmentCancellationSubject() {
    }

    public AppointmentCancellationSubject(List<Observer> observers) {
        if (observers != null) {
            this.observers.addAll(observers);
        }
    }

    @Override
    public void attach(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void detach(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(AppointmentCancelledEvent event) {
        observers.forEach(observer -> observer.update(event));
    }
}