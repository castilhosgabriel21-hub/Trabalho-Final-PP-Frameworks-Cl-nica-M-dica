package com.clinica.observer;

import com.clinica.event.AppointmentCancelledEvent; import com.clinica.repository.WaitingListRepository; import com.clinica.service.NotificationService;
import lombok.RequiredArgsConstructor; import lombok.extern.slf4j.Slf4j; import org.springframework.stereotype.Component; import org.springframework.transaction.annotation.Transactional;

@Slf4j @Component @RequiredArgsConstructor
public class WaitingListNotifier implements Observer {
    private final WaitingListRepository waitingListRepository; private final NotificationService notificationService;
    @Override @Transactional public void update(AppointmentCancelledEvent event) {
        var specialtyId = event.appointment().getDoctor().getSpecialty().getId();
        var entries = waitingListRepository.findBySpecialtyIdAndNotifiedFalse(specialtyId);
        entries.forEach(entry -> { notificationService.send("EMAIL", entry.getPatient().getEmail(), "Horario liberado para " + event.appointment().getDoctor().getSpecialty().getName()); entry.setNotified(true); });
        log.info("{} pacientes da fila notificados", entries.size());
    }
}

