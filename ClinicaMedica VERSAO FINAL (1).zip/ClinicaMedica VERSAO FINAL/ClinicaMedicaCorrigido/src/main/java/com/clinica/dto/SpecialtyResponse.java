package com.clinica.dto;
public record SpecialtyResponse(Long id, String name, String description) {}

