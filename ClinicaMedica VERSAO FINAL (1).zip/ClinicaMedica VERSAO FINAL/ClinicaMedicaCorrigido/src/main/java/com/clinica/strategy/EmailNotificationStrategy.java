package com.clinica.strategy;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailNotificationStrategy implements NotificationStrategy {

    private final JavaMailSender mailSender;

    @Value("${clinica.mail.from}")
    private String from;

    @Override
    public String channel() {
        return "EMAIL";
    }

    @Override
    public void send(String destination, String message) {
        try {
            var email = new SimpleMailMessage();
            email.setFrom(from);
            email.setTo(destination);
            email.setSubject("Lembrete de consulta");
            email.setText(message);
            mailSender.send(email);
            log.info("Email enviado para {}", destination);
        } catch (MailException e) {
            // Loga o erro mas não propaga a exceção para não derrubar o fluxo principal
            // Configure MAIL_HOST, MAIL_USERNAME e MAIL_PASSWORD para envio real
            log.warn("Falha ao enviar email para {} - verifique as configurações de SMTP: {}", destination, e.getMessage());
        }
    }
}
