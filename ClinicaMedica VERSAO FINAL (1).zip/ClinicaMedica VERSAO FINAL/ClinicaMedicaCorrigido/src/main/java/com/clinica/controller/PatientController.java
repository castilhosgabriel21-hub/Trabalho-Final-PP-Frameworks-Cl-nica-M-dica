package com.clinica.controller;
import com.clinica.dto.*; import com.clinica.service.PatientService; import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.data.domain.*; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/patients") @RequiredArgsConstructor
public class PatientController {
    private final PatientService service;
    @PostMapping @ResponseStatus(HttpStatus.CREATED) public PatientResponse create(@RequestBody @Valid PatientRequest r) { return service.create(r); }
    @GetMapping public Page<PatientResponse> list(Pageable pageable) { return service.list(pageable); }
    @GetMapping("/{id}") public PatientResponse find(@PathVariable Long id) { return service.find(id); }
    @PutMapping("/{id}") public PatientResponse update(@PathVariable Long id, @RequestBody @Valid PatientRequest r) { return service.update(id, r); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id) { service.delete(id); }
}

