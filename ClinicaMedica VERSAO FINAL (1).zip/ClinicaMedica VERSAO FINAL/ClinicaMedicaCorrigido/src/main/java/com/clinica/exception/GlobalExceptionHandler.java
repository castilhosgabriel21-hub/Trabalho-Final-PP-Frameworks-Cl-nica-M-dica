package com.clinica.exception;

import org.springframework.http.HttpStatus; import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException; import org.springframework.web.bind.annotation.ExceptionHandler; import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.time.LocalDateTime; import java.util.List;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    ResponseEntity<ErrorResponse> notFound(ResourceNotFoundException ex) { return error(HttpStatus.NOT_FOUND, List.of(ex.getMessage())); }
    @ExceptionHandler(BusinessException.class)
    ResponseEntity<ErrorResponse> business(BusinessException ex) { return error(HttpStatus.CONFLICT, List.of(ex.getMessage())); }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<ErrorResponse> validation(MethodArgumentNotValidException ex) {
        var messages = ex.getFieldErrors().stream().map(e -> e.getField() + ": " + e.getDefaultMessage()).toList();
        return error(HttpStatus.BAD_REQUEST, messages);
    }
    private ResponseEntity<ErrorResponse> error(HttpStatus status, List<String> messages) {
        return ResponseEntity.status(status).body(new ErrorResponse(LocalDateTime.now(), status.value(), status.getReasonPhrase(), messages));
    }
}

