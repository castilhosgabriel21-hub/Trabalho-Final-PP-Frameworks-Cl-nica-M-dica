package com.clinica.dto;
import com.clinica.entity.Role;
public record UserResponse(Long id, String name, String email, Role role) {}

