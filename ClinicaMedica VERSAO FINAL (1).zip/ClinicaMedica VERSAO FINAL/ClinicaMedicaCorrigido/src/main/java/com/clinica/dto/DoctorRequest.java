package com.clinica.dto;
import jakarta.validation.constraints.Email; import jakarta.validation.constraints.NotBlank; import jakarta.validation.constraints.NotNull;
public record DoctorRequest(@NotBlank String name, @NotBlank String crm, @Email @NotBlank String email, @NotBlank String phone, @NotNull Long specialtyId) {}

