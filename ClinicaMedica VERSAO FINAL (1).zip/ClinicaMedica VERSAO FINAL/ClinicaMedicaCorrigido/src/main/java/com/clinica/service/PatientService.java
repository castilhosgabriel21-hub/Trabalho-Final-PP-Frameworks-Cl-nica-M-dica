package com.clinica.service;

import com.clinica.dto.*; import com.clinica.entity.Patient; import com.clinica.exception.ResourceNotFoundException; import com.clinica.repository.PatientRepository; import com.clinica.util.DtoMapper;
import lombok.RequiredArgsConstructor; import org.springframework.data.domain.Page; import org.springframework.data.domain.Pageable; import org.springframework.stereotype.Service;

@Service @RequiredArgsConstructor
public class PatientService {
    private final PatientRepository repository;
    public PatientResponse create(PatientRequest request) { return DtoMapper.patient(repository.save(Patient.builder().name(request.name()).cpf(request.cpf()).email(request.email()).phone(request.phone()).build())); }
    public Page<PatientResponse> list(Pageable pageable) { return repository.findAll(pageable).map(DtoMapper::patient); }
    public Patient getEntity(Long id) { return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Paciente nao encontrado")); }
    public PatientResponse find(Long id) { return DtoMapper.patient(getEntity(id)); }
    public PatientResponse update(Long id, PatientRequest request) { var p = getEntity(id); p.setName(request.name()); p.setCpf(request.cpf()); p.setEmail(request.email()); p.setPhone(request.phone()); return DtoMapper.patient(repository.save(p)); }
    public void delete(Long id) { repository.delete(getEntity(id)); }
}

