package com.clinica.controller;

import com.clinica.dto.*;
import com.clinica.facade.AppointmentFacade;
import com.clinica.service.AppointmentService;
import jakarta.validation.Valid;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    private final AppointmentFacade facade;
    private final AppointmentService service;

    public AppointmentController(AppointmentFacade facade, AppointmentService service) {
        this.facade = facade;
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public AppointmentResponse create(@RequestBody @Valid AppointmentRequest request) {
        return facade.schedule(request);
    }

    @GetMapping
    public Page<AppointmentResponse> list(Pageable pageable) {
        return service.list(pageable);
    }

    @GetMapping("/{id}")
    public AppointmentResponse find(@PathVariable Long id) {
        return service.find(id);
    }

    @PutMapping("/{id}")
    public AppointmentResponse update(@PathVariable Long id,
                                      @RequestBody @Valid AppointmentRequest request) {
        return service.update(id, request);
    }

    @PatchMapping("/{id}/status")
    @ResponseStatus(HttpStatus.OK)
    public AppointmentResponse updateStatus(
            @PathVariable Long id,
            @RequestBody @Valid UpdateAppointmentStatusRequest request) {
        return service.updateStatus(id, request.status());
    }

    @PostMapping("/{id}/reminder")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void sendReminder(@PathVariable Long id) {
        service.sendReminder(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void cancel(@PathVariable Long id) {
        service.cancel(id);
    }
}