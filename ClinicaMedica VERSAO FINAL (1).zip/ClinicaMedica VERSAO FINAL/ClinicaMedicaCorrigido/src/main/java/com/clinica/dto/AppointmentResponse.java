package com.clinica.dto;
import com.clinica.entity.AppointmentStatus;
import java.time.LocalDateTime;
public record AppointmentResponse(Long id, LocalDateTime dateTime, AppointmentStatus status, String notes, PatientResponse patient, DoctorResponse doctor) {}

