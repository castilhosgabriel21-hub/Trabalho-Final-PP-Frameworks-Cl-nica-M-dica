package com.clinica.exception;
public class ConsultaConflitoException extends BusinessException { public ConsultaConflitoException(String message) { super(message); } }

