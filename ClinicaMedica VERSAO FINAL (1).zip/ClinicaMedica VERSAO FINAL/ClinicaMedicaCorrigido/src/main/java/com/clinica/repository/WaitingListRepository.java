package com.clinica.repository;
import com.clinica.entity.WaitingListEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface WaitingListRepository extends JpaRepository<WaitingListEntry, Long> {
    List<WaitingListEntry> findBySpecialtyIdAndNotifiedFalse(Long specialtyId);
}

