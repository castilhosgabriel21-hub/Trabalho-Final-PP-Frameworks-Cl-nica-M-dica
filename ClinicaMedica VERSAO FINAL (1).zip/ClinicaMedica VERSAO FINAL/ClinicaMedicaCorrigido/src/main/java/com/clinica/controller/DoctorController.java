package com.clinica.controller;
import com.clinica.adapter.ExternalDoctorResponse; import com.clinica.dto.*; import com.clinica.service.DoctorService; import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.data.domain.*; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/doctors") @RequiredArgsConstructor
public class DoctorController {
    private final DoctorService service;
    @PostMapping @ResponseStatus(HttpStatus.CREATED) public DoctorResponse create(@RequestBody @Valid DoctorRequest r) { return service.create(r); }
    @GetMapping public Page<DoctorResponse> list(@RequestParam(required = false) String name, Pageable pageable) { return service.list(name, pageable); }
    @GetMapping("/{id}") public DoctorResponse find(@PathVariable Long id) { return service.find(id); }
    @PutMapping("/{id}") public DoctorResponse update(@PathVariable Long id, @RequestBody @Valid DoctorRequest r) { return service.update(id, r); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id) { service.delete(id); }
    @GetMapping("/external") public List<ExternalDoctorResponse> external() { return service.externalDoctors(); }
}

