package com.clinica.service;

import com.clinica.factory.Report; import com.clinica.factory.ReportFactory; import lombok.RequiredArgsConstructor; import org.springframework.stereotype.Service;
import java.time.YearMonth;

@Service @RequiredArgsConstructor
public class ReportService {
    private final AppointmentService appointmentService; private final ReportFactory reportFactory;
    public GeneratedReport generateMonthly(String type, YearMonth month) { Report report = reportFactory.create(type); return new GeneratedReport(report.fileName(), report.contentType(), report.generate(appointmentService.monthlyAppointments(month))); }
    public record GeneratedReport(String fileName, String contentType, byte[] bytes) {}
}

