package com.clinica.factory;

import com.clinica.entity.Appointment; import com.lowagie.text.*; import com.lowagie.text.pdf.PdfWriter;
import java.io.ByteArrayOutputStream; import java.util.List;

public class PDFReport implements Report {
    public byte[] generate(List<Appointment> appointments) {
        try { var out = new ByteArrayOutputStream(); var doc = new Document(); PdfWriter.getInstance(doc, out); doc.open(); doc.add(new Paragraph("Relatorio mensal de consultas")); for (var a : appointments) doc.add(new Paragraph(a.getDateTime() + " - " + a.getPatient().getName() + " - " + a.getDoctor().getName())); doc.close(); return out.toByteArray(); }
        catch (Exception e) { throw new IllegalStateException("Erro ao gerar PDF", e); }
    }
    public String contentType() { return "application/pdf"; }
    public String fileName() { return "relatorio-consultas.pdf"; }
}

