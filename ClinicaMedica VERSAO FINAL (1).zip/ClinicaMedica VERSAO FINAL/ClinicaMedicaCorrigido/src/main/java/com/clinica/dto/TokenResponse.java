package com.clinica.dto;
public record TokenResponse(String token, String type) {}

