package com.clinica.service;

import com.clinica.dto.*; import com.clinica.entity.Specialty; import com.clinica.exception.ResourceNotFoundException; import com.clinica.repository.SpecialtyRepository; import com.clinica.util.DtoMapper;
import lombok.RequiredArgsConstructor; import org.springframework.data.domain.Page; import org.springframework.data.domain.Pageable; import org.springframework.stereotype.Service;

@Service @RequiredArgsConstructor
public class SpecialtyService {
    private final SpecialtyRepository repository;
    public SpecialtyResponse create(SpecialtyRequest request) { return DtoMapper.specialty(repository.save(Specialty.builder().name(request.name()).description(request.description()).build())); }
    public Page<SpecialtyResponse> list(Pageable pageable) { return repository.findAll(pageable).map(DtoMapper::specialty); }
    public Specialty getEntity(Long id) { return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Especialidade nao encontrada")); }
    public SpecialtyResponse find(Long id) { return DtoMapper.specialty(getEntity(id)); }
    public SpecialtyResponse update(Long id, SpecialtyRequest request) { var s = getEntity(id); s.setName(request.name()); s.setDescription(request.description()); return DtoMapper.specialty(repository.save(s)); }
    public void delete(Long id) { repository.delete(getEntity(id)); }
}

