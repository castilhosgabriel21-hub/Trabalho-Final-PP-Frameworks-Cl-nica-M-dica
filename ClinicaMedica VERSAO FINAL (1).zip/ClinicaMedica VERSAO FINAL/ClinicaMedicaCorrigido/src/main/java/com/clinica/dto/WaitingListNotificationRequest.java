package com.clinica.dto;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

public record WaitingListNotificationRequest(@NotNull LocalDateTime appointmentDateTime) {}