package com.clinica.dto;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
public record WaitingListRequest(@NotNull Long patientId, @NotNull Long specialtyId, LocalDateTime desiredDateTime) {}
