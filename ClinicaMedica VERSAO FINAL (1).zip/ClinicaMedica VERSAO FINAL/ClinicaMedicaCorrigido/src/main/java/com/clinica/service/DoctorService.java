package com.clinica.service;

import com.clinica.adapter.ExternalDoctorGateway; import com.clinica.adapter.ExternalDoctorResponse; import com.clinica.dto.*; import com.clinica.entity.Doctor; import com.clinica.exception.ResourceNotFoundException; import com.clinica.repository.DoctorRepository; import com.clinica.util.DtoMapper;
import lombok.RequiredArgsConstructor; import org.springframework.data.domain.Page; import org.springframework.data.domain.Pageable; import org.springframework.stereotype.Service;
import java.util.List;

@Service @RequiredArgsConstructor
public class DoctorService {
    private final DoctorRepository repository; private final SpecialtyService specialtyService; private final ExternalDoctorGateway externalDoctorGateway;
    public DoctorResponse create(DoctorRequest request) { var specialty = specialtyService.getEntity(request.specialtyId()); return DtoMapper.doctor(repository.save(Doctor.builder().name(request.name()).crm(request.crm()).email(request.email()).phone(request.phone()).specialty(specialty).build())); }
    public Page<DoctorResponse> list(String name, Pageable pageable) { return (name == null ? repository.findAll(pageable) : repository.findByNameContainingIgnoreCase(name, pageable)).map(DtoMapper::doctor); }
    public Doctor getEntity(Long id) { return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Medico nao encontrado")); }
    public DoctorResponse find(Long id) { return DtoMapper.doctor(getEntity(id)); }
    public DoctorResponse update(Long id, DoctorRequest request) { var d = getEntity(id); d.setName(request.name()); d.setCrm(request.crm()); d.setEmail(request.email()); d.setPhone(request.phone()); d.setSpecialty(specialtyService.getEntity(request.specialtyId())); return DtoMapper.doctor(repository.save(d)); }
    public void delete(Long id) { repository.delete(getEntity(id)); }
    public List<ExternalDoctorResponse> externalDoctors() { return externalDoctorGateway.fetchDoctors(); }
}

