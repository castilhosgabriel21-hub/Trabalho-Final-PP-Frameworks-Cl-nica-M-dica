package com.clinica.dto;
import java.time.LocalDateTime;
public record WaitingListResponse(Long id, PatientResponse patient, SpecialtyResponse specialty, LocalDateTime desiredDateTime, boolean notified) {}
