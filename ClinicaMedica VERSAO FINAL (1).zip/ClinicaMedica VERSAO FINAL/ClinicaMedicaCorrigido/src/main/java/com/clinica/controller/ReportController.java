package com.clinica.controller;

import com.clinica.service.ReportService; import lombok.RequiredArgsConstructor; import org.springframework.http.*; import org.springframework.web.bind.annotation.*;
import java.time.YearMonth;

@RestController @RequestMapping("/reports") @RequiredArgsConstructor
public class ReportController {
    private final ReportService reportService;
    @GetMapping("/appointments/monthly") public ResponseEntity<byte[]> monthly(@RequestParam(defaultValue = "pdf") String type, @RequestParam(required = false) YearMonth month) {
        var report = reportService.generateMonthly(type, month == null ? YearMonth.now() : month);
        return ResponseEntity.ok().contentType(MediaType.parseMediaType(report.contentType())).header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + report.fileName()).body(report.bytes());
    }
}

