package com.clinica.config;

import com.clinica.security.SecurityFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final SecurityFilter securityFilter;

    public SecurityConfig(SecurityFilter securityFilter) {
        this.securityFilter = securityFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> {
                    // Públicos (sem autenticação)
                    auth.requestMatchers("/", "/error", "/web/**", "/css/**", "/js/**", "/images/**").permitAll();
                    auth.requestMatchers(HttpMethod.POST, "/auth/**").permitAll();
                    auth.requestMatchers(HttpMethod.GET, "/auth/**").permitAll();

                    // Doctors: apenas ADMIN
                    auth.requestMatchers(HttpMethod.POST, "/doctors").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.PUT, "/doctors/**").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.DELETE, "/doctors/**").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.GET, "/doctors").authenticated();
                    auth.requestMatchers(HttpMethod.GET, "/doctors/**").authenticated();

                    // Appointments: ADMIN pode tudo, USER só lê
                    auth.requestMatchers(HttpMethod.POST, "/appointments").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.PUT, "/appointments/**").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.PATCH, "/appointments/**").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.DELETE, "/appointments/**").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.GET, "/appointments").authenticated();
                    auth.requestMatchers(HttpMethod.GET, "/appointments/**").authenticated();

                    // Reports, Users, Specialties: ADMIN só
                    auth.requestMatchers("/reports/**").hasRole("ADMIN");
                    auth.requestMatchers("/users/**").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.POST, "/specialties").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.PUT, "/specialties/**").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.DELETE, "/specialties/**").hasRole("ADMIN");
                    auth.requestMatchers(HttpMethod.GET, "/specialties").authenticated();
                    auth.requestMatchers(HttpMethod.GET, "/specialties/**").authenticated();

                    // Waiting list
                    auth.requestMatchers("/waiting-list/**").authenticated();

                    // Tudo mais precisa autenticação
                    auth.anyRequest().authenticated();
                })
                .addFilterBefore(securityFilter, UsernamePasswordAuthenticationFilter.class);
        // ❌ REMOVIDO: .build() - NÃO PODE TER DOIS!

        return http.build(); // ✅ ÚNICO build() - CORRETO!
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
