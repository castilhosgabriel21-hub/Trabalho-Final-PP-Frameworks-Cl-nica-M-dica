package com.clinica.dto;
public record DoctorResponse(Long id, String name, String crm, String email, String phone, SpecialtyResponse specialty) {}

