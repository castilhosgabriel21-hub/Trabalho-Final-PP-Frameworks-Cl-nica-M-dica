package com.clinica.service;

import com.clinica.dto.WaitingListNotificationRequest;
import com.clinica.dto.WaitingListRequest;
import com.clinica.dto.WaitingListResponse;
import com.clinica.entity.WaitingListEntry;
import com.clinica.exception.ResourceNotFoundException;
import com.clinica.repository.WaitingListRepository;
import com.clinica.util.DtoMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
@RequiredArgsConstructor
public class WaitingListService {
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final WaitingListRepository repository;
    private final PatientService patientService;
    private final SpecialtyService specialtyService;
    private final NotificationService notificationService;

    public WaitingListResponse create(WaitingListRequest request) {
        var entry = WaitingListEntry.builder()
            .patient(patientService.getEntity(request.patientId()))
            .specialty(specialtyService.getEntity(request.specialtyId()))
            .desiredDateTime(request.desiredDateTime())
            .notified(false)
            .build();
        return map(repository.save(entry));
    }

    public Page<WaitingListResponse> list(Pageable pageable) {
        return repository.findAll(pageable).map(this::map);
    }

    public WaitingListResponse find(Long id) {
        return map(getEntity(id));
    }

    @Transactional
    public WaitingListResponse notifyByEmail(Long id, WaitingListNotificationRequest request) {
        var entry = getEntity(id);
        entry.setDesiredDateTime(request.appointmentDateTime());
        entry.setNotified(true);
        notificationService.send("EMAIL", entry.getPatient().getEmail(), appointmentMarkedMessage(request.appointmentDateTime()));
        return map(repository.save(entry));
    }

    public void delete(Long id) {
        repository.delete(getEntity(id));
    }

    private WaitingListEntry getEntity(Long id) {
        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Entrada da fila nao encontrada"));
    }

    public static String appointmentMarkedMessage(LocalDateTime appointmentDateTime) {
        return "Sua consulta foi marcada para data tal (" + appointmentDateTime.format(DATE_TIME_FORMATTER) + ").";
    }

    private WaitingListResponse map(WaitingListEntry e) {
        return new WaitingListResponse(e.getId(), DtoMapper.patient(e.getPatient()), DtoMapper.specialty(e.getSpecialty()), e.getDesiredDateTime(), e.isNotified());
    }
}