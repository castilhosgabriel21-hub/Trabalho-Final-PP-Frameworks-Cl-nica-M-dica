package com.clinica.dto;
import com.clinica.entity.Role;
import jakarta.validation.constraints.Email; import jakarta.validation.constraints.NotBlank; import jakarta.validation.constraints.NotNull;
public record UserRequest(@NotBlank String name, @Email @NotBlank String email, @NotBlank String password, @NotNull Role role) {}

