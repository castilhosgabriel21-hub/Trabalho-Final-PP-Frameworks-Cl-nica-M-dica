package com.clinica.repository;
import com.clinica.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PatientRepository extends JpaRepository<Patient, Long> { boolean existsByCpf(String cpf); }

