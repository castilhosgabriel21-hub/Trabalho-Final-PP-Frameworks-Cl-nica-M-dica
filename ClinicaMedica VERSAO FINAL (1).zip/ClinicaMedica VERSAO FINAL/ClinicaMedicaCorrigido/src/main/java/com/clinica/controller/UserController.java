package com.clinica.controller;
import com.clinica.dto.*; import com.clinica.service.UserService; import jakarta.validation.Valid; import lombok.RequiredArgsConstructor; import org.springframework.data.domain.*; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/users") @RequiredArgsConstructor
public class UserController {
    private final UserService service;
    @PostMapping @ResponseStatus(HttpStatus.CREATED) public UserResponse create(@RequestBody @Valid UserRequest r) { return service.create(r); }
    @GetMapping public Page<UserResponse> list(Pageable pageable) { return service.list(pageable); }
    @GetMapping("/{id}") public UserResponse find(@PathVariable Long id) { return service.find(id); }
    @PutMapping("/{id}") public UserResponse update(@PathVariable Long id, @RequestBody @Valid UserRequest r) { return service.update(id, r); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id) { service.delete(id); }
}
