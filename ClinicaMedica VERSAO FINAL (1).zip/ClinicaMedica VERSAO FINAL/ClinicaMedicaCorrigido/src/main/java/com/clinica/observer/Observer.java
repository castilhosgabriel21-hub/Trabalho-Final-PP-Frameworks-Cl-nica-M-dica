package com.clinica.observer;

import com.clinica.event.AppointmentCancelledEvent;

public interface Observer {
    void update(AppointmentCancelledEvent event);
}