package com.clinica.dto;

import jakarta.validation.constraints.NotBlank;

public record UpdateAppointmentStatusRequest(
    @NotBlank(message = "Status é obrigatório")
    String status
) { }
