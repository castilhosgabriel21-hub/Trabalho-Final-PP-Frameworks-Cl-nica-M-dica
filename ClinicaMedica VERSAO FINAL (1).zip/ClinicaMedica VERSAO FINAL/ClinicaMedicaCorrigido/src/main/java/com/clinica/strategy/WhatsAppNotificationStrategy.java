package com.clinica.strategy;
import lombok.extern.slf4j.Slf4j; import org.springframework.stereotype.Component;
@Slf4j @Component
public class WhatsAppNotificationStrategy implements NotificationStrategy { public String channel() { return "WHATSAPP"; } public void send(String destination, String message) { log.info("WhatsApp para {}: {}", destination, message); } }

