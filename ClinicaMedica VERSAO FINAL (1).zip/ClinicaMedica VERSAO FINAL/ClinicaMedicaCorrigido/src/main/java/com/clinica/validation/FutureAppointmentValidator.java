package com.clinica.validation;

import jakarta.validation.ConstraintValidator; import jakarta.validation.ConstraintValidatorContext;
import java.time.LocalDateTime;

public class FutureAppointmentValidator implements ConstraintValidator<FutureAppointment, LocalDateTime> {
    @Override public boolean isValid(LocalDateTime value, ConstraintValidatorContext context) {
        return value != null && value.isAfter(LocalDateTime.now());
    }
}

