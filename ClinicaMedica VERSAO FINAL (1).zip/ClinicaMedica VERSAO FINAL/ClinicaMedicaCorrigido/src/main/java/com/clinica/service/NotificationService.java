package com.clinica.service;

import com.clinica.strategy.NotificationStrategy; import org.springframework.stereotype.Service;
import java.util.Map; import java.util.function.Function; import java.util.stream.Collectors;

@Service
public class NotificationService {
    private final Map<String, NotificationStrategy> strategies;
    public NotificationService(java.util.List<NotificationStrategy> strategies) { this.strategies = strategies.stream().collect(Collectors.toMap(NotificationStrategy::channel, Function.identity())); }
    public void send(String channel, String destination, String message) { strategies.getOrDefault(channel, strategies.get("EMAIL")).send(destination, message); }
}

