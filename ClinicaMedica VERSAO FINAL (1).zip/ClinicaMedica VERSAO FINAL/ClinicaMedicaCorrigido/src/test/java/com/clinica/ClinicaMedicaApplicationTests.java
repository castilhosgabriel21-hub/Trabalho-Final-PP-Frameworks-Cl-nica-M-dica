package com.clinica;
import org.junit.jupiter.api.Test;
class ClinicaMedicaApplicationTests { @Test void applicationClassExists() { new ClinicaMedicaApplication(); } }
